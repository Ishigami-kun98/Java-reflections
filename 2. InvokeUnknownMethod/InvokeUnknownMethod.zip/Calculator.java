package lab2;

public class Calculator {
    public int add(int a, int b) {
        return a + b;
    }

    public int mul(int a, int b) {
        return a * b;
    }

    public double divi(double a, double b) {
        return a / b;
    }

    public double neg(double a) {
        return -a;
    }
}