class TestClass extends SuperClass implements interfacetest {
    public void add() {

    }

    public int dieci() {
        return 10;
    }

    @Override
    public String toString() {
        return "TestClass []";
    }

    @Override
    public void prova() {
        // TODO Auto-generated method stub

    }

}