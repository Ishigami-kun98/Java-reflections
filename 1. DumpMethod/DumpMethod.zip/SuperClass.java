class SuperClass {
    public void tries() {

    }
}