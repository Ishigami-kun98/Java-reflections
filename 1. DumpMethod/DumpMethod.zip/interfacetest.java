interface interfacetest {
    void prova();
}